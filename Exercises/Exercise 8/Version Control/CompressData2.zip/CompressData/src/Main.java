import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//        String file = input.nextLine();
//        DataInputStream dataInput =
//                new DataInputStream(new BufferedInputStream(
//                        Objects.requireNonNull(Main.class.getResourceAsStream(file))));


        Huffman huffman = new Huffman("alle barna elsker selskap");

        FrequencyTree frequencyTree = huffman.huffmanTree();
        frequencyTree.printTree();
        huffman.addBinaryVal();
        frequencyTree.printTree();

    }
}

class LempelZiv {

    static byte[] data;
    static byte[] buffer;

    public static DataOutputStream lz(DataInputStream in) throws IOException{

        buffer = new byte[1024*32];
        data = in.readAllBytes();

        for(int i = 0; i<data.length; i++){
            int startPos = inBuffer(data[i], i);
            if(startPos == -1){
                addToBuffer(data[i], i);
            }
            else {

            }

        }

        return null;
    }

    public static int inBuffer(byte b, int pos){
        for(int i = pos; i>=0; i--){
            if (buffer[i] == b) return i;
        }
        return -1;
    }

    public static void addToBuffer(byte b, int pos){
        buffer[pos%buffer.length] = b;
    }

}

//TODO: replace hashmap later

class Huffman {
    
    HashMap<Character, Integer> symbolMap = new HashMap<>();
    Heap heap;

    public Huffman(String text) {
        for(char character : text.toCharArray()){
            symbolMap.merge(character, 1, Integer::sum);
        }

        heap = new Heap(createFrequencyTree(text));
    }

    public FrequencyTree[] createFrequencyTree(String text){
        FrequencyTree[] frequencyTrees = new FrequencyTree[symbolMap.size()];
        int i = 0;
        for(char character : text.toCharArray()){
            if(symbolMap.get(character) != 0){
                frequencyTrees[i] = new FrequencyTree(
                        new LeafNode(character, symbolMap.get(character), null));
                i++;
                symbolMap.put(character, 0);
            }
        }
        return frequencyTrees;
    }

    public FrequencyTree huffmanTree(){
        while (heap.len > 1){
            System.out.println(heap.printHeap());
            createSubTree();
        }

        return heap.queue[0];
    }

    public void createSubTree(){
        FrequencyTree newTree;
        FrequencyTree rightSubTree = heap.poll();
        FrequencyTree leftSubTree = heap.poll();

        if(rightSubTree.frequency() < leftSubTree.frequency()){
            newTree = new FrequencyTree(rightSubTree, leftSubTree);
        }
        else{
            newTree = new FrequencyTree(leftSubTree, rightSubTree);
        }

        heap.add(newTree);
    }

    public void addBinaryVal(){
        addBinaryVal(this.heap.queue[0].root);
    }

    public void addBinaryVal(Node node){
        if(node.left != null){
            node.left.binaryVal = node.left.parent.binaryVal + "0";
            addBinaryVal(node.left);
        }
        if(node.right != null){
            node.right.binaryVal = node.right.parent.binaryVal + "1";
            addBinaryVal(node.right);
        }
    }

    
}

/**
 * This is a form for priority queue.
 */
class Heap{
    int len;
    int capacity = 10;
    FrequencyTree[] queue;

    public Heap(FrequencyTree[] nodes){
        this.queue = nodes;
        len = queue.length;
        createHeap();
    }

    /**
     * This method takes a tree, that may not have a heap structure at all, and makes it into a max heap.
     */
    public void createHeap(){
        int i = len/2;
        while(i-- > 0) heapifyDown(i); //Dont really need this if I am using the minSort method.
        minSort();
    }

    //TODO: make my own
    public void minSort(){
        //This method doesn't work since it sorts the whole array which includes nodes that have been "removed"
        Arrays.sort(queue, Comparator.comparing(FrequencyTree::frequency));
        /*
            However, this sort method can be used the first time when the array only contains the origianl values...
         */
    }


    /**
     * This method allows a FrequencyTree to be added to the heap.
     * @param tree    Tree to be added.
     */
    public void add(FrequencyTree tree){
        updateLength();
        queue[len - 1] = tree;
//        minSort();
        heapifyUp();
    }


    /**
     * This method makes sure the heap structure is kept by starting at the last node and checking that it is correct.
     */
    private void heapifyUp(){
        int index = len - 1;
        while(hasParent(index) && parent(index).frequency() > queue[index].frequency()){
            swap(getParentIndex(index), index);
            index = getParentIndex(index);
        }
    }

    /**
     * If a vertex breaks the max heap structure, then this method can fix the structure.
     * @param index The index of the vertex breaking the structure.
     */
    public void heapifyUp(int index){
        int parentIndex = getParentIndex(index);
        while(parentIndex > 0 && queue[index].frequency() < queue[parentIndex].frequency()){
            swap(index, parentIndex);
            index = parentIndex;
            parentIndex = getParentIndex(index);
        }
    }

    /**
     * This method makes sure the heap structure is kept by starting at the first node and checking that it is valid.
     */
    private void heapifyDown(){
        int index = 0;

        while(hasLeftChild(index)){
            int smallerChild = getLeftChild(index);
            if(hasRightChild(index) && leftChild(index).frequency() > rightChild(index).frequency()){
                smallerChild += 1;
            }
            if(queue[index].frequency() > queue[smallerChild].frequency()){
                swap(index, smallerChild);
                index = smallerChild;
            }
            else return;
        }
    }

    /**
     * If a vertex breaks the max heap structure, then this method can fix the structure.
     * @param index The index of the vertex breaking the structure.
     */
    public void heapifyDown(int index){
        int leftChildIndex = getLeftChild(index);
        if(leftChildIndex < len){
            int rightChildIndex = leftChildIndex + 1;
            if(rightChildIndex < len && queue[rightChildIndex].frequency() < queue[leftChildIndex].frequency()){
                leftChildIndex = rightChildIndex;
            }
            if(queue[leftChildIndex].frequency() < queue[index].frequency()){
                swap(index, leftChildIndex);
                heapifyDown(leftChildIndex);
            }
        }
    }

    /**
     * This method returns the head of the heap, if it exists.
     * @return                              If head exists, return head node. Else, throw IllegalArgumentException.
     * @throws IllegalArgumentException     If the root Node does not exist.
     */
    public FrequencyTree peek() throws IllegalArgumentException{
        if(len == 0) throw new IllegalArgumentException("There is currently no root node.");
        return queue[0];
    }

    /**
     * This method extracts (removes) the root FrequencyTree.
     * @return  The root tree, represented as a FrequencyTree.
     */
    public FrequencyTree poll() throws IllegalArgumentException{
        if(len == 0) throw new IllegalArgumentException("There is currently no root node.");
        FrequencyTree root = queue[0];
        queue[0] = queue[--len];
        heapifyDown();
        return root;
    }

    public void updateLength(){
        if(capacity == len++){
            capacity = capacity << 1;
            queue = Arrays.copyOf(this.queue, capacity);
        }
    }

    /**
     * This method swaps the queue at the given indices.
     * @param index1    Index of the first Node, represented as an int.
     * @param index2    Index of the second Node, represented as an int.
     */
    private void swap(int index1, int index2){
        FrequencyTree temp = queue[index1];
        queue[index1] = queue[index2];
        queue[index2] = temp;
    }

    /**
     * This method checks if a given node has a parent node.
     * @param index The index of the node, given as an int.
     * @return      {@code true} if the node has a parent; otherwise, {@code false}
     */
    private boolean hasParent(int index){
        return getParentIndex(index) >= 0;
    }

    /**
     * This method checks if a given node has a left child node.
     * @param index The index of the node, given as an int.
     * @return      {@code true} if the node has a left child node; otherwise, {@code false}
     */
    private boolean hasLeftChild(int index){
        return getLeftChild(index) < len;
    }

    /**
     * This method checks if a given node has a right child node.
     * @param index The index of the node, given as an int.
     * @return      {@code true} if the node has a right child node; otherwise, {@code false}
     */
    private boolean hasRightChild(int index){
        return getRightChild(index) < len;
    }

    /**
     * This method retrieves the parent Node of the given Node.
     * @param index Index of the child node, represented as an int.
     * @return      Node of the parent node.
     */
    private FrequencyTree parent(int index){
        return queue[getParentIndex(index)];
    }

    /**
     * This method retrieves the left child Node of the given Node.
     * @param index Index of the parent node, represented as an int.
     * @return      Node of the left child node.
     */
    private FrequencyTree leftChild(int index){
        return queue[getLeftChild(index)];
    }

    /**
     * This method retrieves the right child Node of the given Node.
     * @param index Index of the parent node, represented as an int.
     * @return      Node of the right child node.
     */
    private FrequencyTree rightChild(int index){
        return queue[getRightChild(index)];
    }


    /**
     * This method gets the index of the parent node in the tree.
     * @param index Index of the node being evaluated, given as an int.
     * @return      Index of the parent node, given as an int.
     */
    public int getParentIndex(int index){
        return (index - 1)>>1;
    }

    /**
     * This method retrieves the index of the left child of a given node.
     * @param index The parent node, given as an int.
     * @return      The index of the left child node, given as an int.
     */
    public int getLeftChild(int index){
        return 1 + (index<<1);
    }

    /**
     * This method retrieves the index of the right child of a given node.
     * @param index The parent node, given as an int.
     * @return      The index of the right child node, given as an int.
     */
    public int getRightChild(int index){
        return 1 << index + 1;
    }

    /**
     * This method creates a string with all the values of the heap concatenated.
     * @return String presenting the values of the nodes in the heap in order.
     */
    public String printHeap(){
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < len; i++){
            sb.append(queue[i]).append("    ");
        }
        return sb.toString();
    }
}


class FrequencyTree {
    Node root;

    public FrequencyTree(Node root) {
        this.root = root;
    }

    public FrequencyTree(FrequencyTree leftSubTree, FrequencyTree rightSubTree){
        int totalFrequency = leftSubTree.frequency() + rightSubTree.frequency();
        this.root = new Node(totalFrequency, leftSubTree.root, rightSubTree.root, null);
        leftSubTree.root.parent = this.root;
        rightSubTree.root.parent = this.root;
    }

    public int frequency(){
        return root.frequency;
    }

    private int totHeight(){
        return height(this.root);
    }
    private int height(Node currentNode){
        if (currentNode == null){
            return -1;
        }

        int leftHeight = height(currentNode.left);
        int rightHeight = height(currentNode.right);

        if(leftHeight >= rightHeight) return leftHeight + 1;
        else return rightHeight + 1;
    }

    private int findDepth(Node node){
        int depth = -1;
        while(node != null){
            node = node.parent;
            depth++;
        }
        return depth;
    }

    public void printTree(){
        StringBuilder sb = new StringBuilder();
        sb.append("========== Tree =========");
        if(this.root == null) throw new IllegalArgumentException("Tree has to have a root.");

        Stack<Node> stackOfNodes = new Stack<>();
        stackOfNodes.push(this.root);

        int currentLevel = 0;

        while(!stackOfNodes.empty()){
            Node node = stackOfNodes.pop();
            System.out.println(node + " " + findDepth(node));

            if(findDepth(node) != currentLevel){
                currentLevel++;
                sb.append("\n");

            }
            for(int i = 0; i < totHeight() - currentLevel; i++){
                sb.append("          ");
            }
            sb.append(node);

            if(node.left != null){
                stackOfNodes.add(0, node.left);
            }

            if(node.right != null){
                stackOfNodes.add(0, node.right);
            }
        }

        System.out.println(sb.toString());
    }

    @Override
    public String toString() {
        return "FrequencyTree: " + root;
    }
}

class Node {
    int frequency;
    Node left;
    Node right;
    Node parent;
    String binaryVal = "";

    public Node(int frequency, Node left, Node right, Node parent) {
        this.frequency = frequency;
        this.left = left;
        this.right = right;
        this.parent = parent;
    }

    @Override
    public String toString() {
        return "Node: " + "frequency = " + frequency;
    }
}

class LeafNode extends Node {
    char letter;

    public LeafNode(char letter, int frequency, Node parent) {
        super(frequency, null, null, parent);
        this.letter = letter;
    }


    @Override
    public String toString() {
        return  letter + ", " + frequency + ", " + binaryVal;
    }
}



/*
    TODO: Currently, the sort function can't be used multiple times because the array still has the
    other
 */