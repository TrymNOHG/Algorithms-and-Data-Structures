import java.util.Random;

public class UnorderedNumbers {

    public static void main(String[] args) {

        NumberArray singlePivotArr = new NumberArray(1000000);
        singlePivotQuickSort(singlePivotArr.getUnorderedArr(), 0, singlePivotArr.getUnorderedArr().length - 1);
        NumberArray dualPivotArr = new NumberArray(1000000);
        dualPivotQuickSort(dualPivotArr.getUnorderedArr(), 0, dualPivotArr.getUnorderedArr().length - 1);


        //single pivot

        final int valueBefore2 = singlePivotArr.getSumOfArrayValuesBefore();
        long startTime2 = System.nanoTime();
        singlePivotQuickSort(singlePivotArr.getUnorderedArr(), 0, singlePivotArr.getUnorderedArr().length - 1);
        long endTime2 = System.nanoTime();
        long time2 = ((endTime2 - startTime2) / 1000000);
        final int valueAfter2 = singlePivotArr.getSumOfArrayValues(singlePivotArr.getUnorderedArr());
        int valueDifference2 = valueAfter2 - valueBefore2;
        System.out.println("Forskjellen på liste før kjøring, og liste etter kjøring er: " + valueDifference2);
        singlePivotArr.isArrOrdered(singlePivotArr.getUnorderedArr());
        System.out.println("Milli second used in single pivot was: " + time2);
        System.out.println("\n \n");

        //dual pivot

        final int valueBefore = dualPivotArr.getSumOfArrayValuesBefore();
        long startTime = System.nanoTime();
        dualPivotQuickSort(dualPivotArr.getUnorderedArr(), 0, dualPivotArr.getUnorderedArr().length - 1);
        long endTime = System.nanoTime();
        long time = ((endTime - startTime) / 1000000);
        final int valueAfter = dualPivotArr.getSumOfArrayValues(dualPivotArr.getUnorderedArr());
        int valueDifference = valueAfter - valueBefore;
        System.out.println("Forskjellen på liste før kjøring, og liste etter kjøring er: " + valueDifference);
        dualPivotArr.isArrOrdered(dualPivotArr.getUnorderedArr());
        System.out.println("Milli second used in dual pivot was: " + time);
        System.out.println("\n \n");

    }


    public static void singlePivotQuickSort(int[] t, int v, int h) {
        if (h - v > 2) {
            int delepos = splitt(t, v, h);
            singlePivotQuickSort(t, v, delepos - 1);
            singlePivotQuickSort(t, delepos + 1, h);
        } else median3sort(t, v, h);
    }

    public static int median3sort(int[] t, int v, int h) {
        int m = (v + h) / 2;
        if (t[v] > t[m]) bytt(t, v, m);
        if (t[m] > t[h]) {
            bytt(t, m, h);
            if (t[v] > t[m]) bytt(t, v, m);
        }
        return m;
    }

    public static void bytt(int[] t, int i, int j) {
        int k = t[j];
        t[j] = t[i];
        t[i] = k;
    }

    public static int splitt(int[] t, int v, int h) {
        int iv, ih;
        int m = median3sort(t, v, h);
        int dv = t[m];
        bytt(t, m, h - 1);
        for (iv = v, ih = h - 1; ; ) {
            while (t[++iv] < dv) ;
            while (t[--ih] > dv) ;
            if (iv >= ih) break;
            bytt(t, iv, ih);
        }
        bytt(t, iv, h - 1);
        return iv;
    }

    // Java program to implement
    // dual pivot QuickSort
    static void swap(int[] arr, int i, int j)
    {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    /**
     * Dual pivot
     * @param arr
     * @param low
     * @param high
     */
    static void dualPivotQuickSort(int[] arr,
                                   int low, int high)
    {
        if (low < high)
        {

            // piv[] stores left pivot and right pivot.
            // piv[0] means left pivot and
            // piv[1] means right pivot
            int[] piv;
            piv = partition(arr, low, high);

            dualPivotQuickSort(arr, low, piv[0] - 1);
            dualPivotQuickSort(arr, piv[0] + 1, piv[1] - 1);
            dualPivotQuickSort(arr, piv[1] + 1, high);
        }
    }

    static int[] partition(int[] arr, int low, int high)
    {
        if (arr[low] > arr[high])
            swap(arr, low, high);

        // p is the left pivot, and q
        // is the right pivot.
        int j = low + 1;
        int g = high - 1, k = low + 1,
                p = arr[low], q = arr[high];

        while (k <= g)
        {

            // If elements are less than the left pivot
            if (arr[k] < p)
            {
                swap(arr, k, j);
                j++;
            }

            // If elements are greater than or equal
            // to the right pivot
            else if (arr[k] >= q)
            {
                while (arr[g] > q && k < g)
                    g--;

                swap(arr, k, g);
                g--;

                if (arr[k] < p)
                {
                    swap(arr, k, j);
                    j++;
                }
            }
            k++;
        }
        j--;
        g++;

        // Bring pivots to their appropriate positions.
        swap(arr, low, j);
        swap(arr, high, g);

        // Returning the indices of the pivots
        // because we cannot return two elements
        // from a function, we do that using an array.
        return new int[] { j, g };
    }

    public static int adder(int[] array){
        int sum = 0;
        for(int i = 0; i <= array.length - 1; i++){
            sum += array[i];
        }
        return sum;
    }

}

/**
 * This class handles the creation of a random, unordered array of numbers.
 */
class NumberArray{
    private Random random = new Random(System.currentTimeMillis());
    private int[] unorderedArr;
    final private int sumOfArrayValuesBefore;

    public NumberArray(int sizeOfArr){
        createRandomArr(sizeOfArr);
        this.sumOfArrayValuesBefore = getSumOfArrayValues(this.unorderedArr);
    }

    /**
     * This method fills the unordered array with random numbers (0 to 100) with a specified number of indices.
     * @param sizeOfArr The desired length of the array, represented as an int.
     */
    public void createRandomArr(int sizeOfArr){
        this.unorderedArr = new int[sizeOfArr];
        for (int i = 0; i < sizeOfArr; i++) {
            this.unorderedArr[i] = random.nextInt(1000000);
        }
    }

    /**
     * This method checks if the input array is properly sorted from lowest to highest value.
     * @param arr The array to be checked, given as an integer array.
     * @return    If the array has an index bigger than the preceding index it returns {@code false}, else {@code true}.
     */
    public boolean isArrOrdered(int[] arr) {
        for(int i = 0; i < arr.length - 1; i++){
            if(arr[i] > arr[i+1]){
                System.out.println("The array is not sorted and this test has therefore failed.");
                return false;
            }
        }
        System.out.println("The array is sorted and this test was successful!");
        return true;
    }

    /**
     * This method returns the sum of all the elements of the given array.
     * @param arr A given integer array
     * @return Sum of the elements of the given array, represented as an int.
     */
    public int getSumOfArrayValues(int[] arr) {
        int sumOfElements = 0;
        for(int element : arr){
            sumOfElements += element;
        }
        return sumOfElements;
    }

    public int[] getUnorderedArr() {
        return unorderedArr;
    }

    public int getSumOfArrayValuesBefore() {
        return sumOfArrayValuesBefore;
    }
}
